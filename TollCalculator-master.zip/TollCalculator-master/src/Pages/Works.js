import React from 'react'

function Works() {
  return (
    <div>
        <h1>Works</h1>
    </div>
  )
}

export default Works